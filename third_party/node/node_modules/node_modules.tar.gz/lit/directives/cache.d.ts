/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
export * from 'lit-html/directives/cache.js';
//# sourceMappingURL=cache.d.ts.map