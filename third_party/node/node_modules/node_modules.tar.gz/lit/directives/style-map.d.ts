/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
export * from 'lit-html/directives/style-map.js';
//# sourceMappingURL=style-map.d.ts.map