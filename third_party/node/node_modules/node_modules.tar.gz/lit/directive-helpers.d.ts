/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
export * from 'lit-html/directive-helpers.js';
//# sourceMappingURL=directive-helpers.d.ts.map