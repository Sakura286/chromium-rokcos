/** @deprecated */
export var Markers;
(function (Markers) {
    Markers["start"] = "/**";
    Markers["nostart"] = "/***";
    Markers["delim"] = "*";
    Markers["end"] = "*/";
})(Markers = Markers || (Markers = {}));
